`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [1:0] PI_axi_rresp;
  reg [0:0] PI_reset_later;
  reg [2:0] PI_line_wr_data_beat;
  reg [0:0] PI_axi_bvalid;
  wire [0:0] PI_clock = clock;
  reg [0:0] PI_line_wr_data_valid;
  reg [0:0] PI_line_wr_req_valid;
  reg [3:0] PI_line_wr_data_id;
  reg [0:0] PI_axi_awready;
  reg [0:0] PI_axi_rvalid;
  reg [3:0] PI_axi_bid;
  reg [3:0] PI_line_rd_req_id;
  reg [0:0] PI_axi_wready;
  reg [1:0] PI_axi_bresp;
  reg [3:0] PI_line_wr_req_id;
  reg [0:0] PI_line_rd_data_ready;
  reg [63:0] PI_axi_rdata;
  reg [0:0] PI_line_wr_rsp_ready;
  reg [31:0] PI_line_rd_req_addr;
  reg [0:0] PI_line_wr_data_last;
  reg [63:0] PI_line_wr_data;
  reg [0:0] PI_axi_arready;
  reg [3:0] PI_axi_rid;
  reg [0:0] PI_axi_rlast;
  reg [0:0] PI_line_rd_req_valid;
  reg [31:0] PI_line_wr_req_addr;
  ReviewAxiAwFormal UUT (
    .axi_rresp(PI_axi_rresp),
    .reset_later(PI_reset_later),
    .line_wr_data_beat(PI_line_wr_data_beat),
    .axi_bvalid(PI_axi_bvalid),
    .clock(PI_clock),
    .line_wr_data_valid(PI_line_wr_data_valid),
    .line_wr_req_valid(PI_line_wr_req_valid),
    .line_wr_data_id(PI_line_wr_data_id),
    .axi_awready(PI_axi_awready),
    .axi_rvalid(PI_axi_rvalid),
    .axi_bid(PI_axi_bid),
    .line_rd_req_id(PI_line_rd_req_id),
    .axi_wready(PI_axi_wready),
    .axi_bresp(PI_axi_bresp),
    .line_wr_req_id(PI_line_wr_req_id),
    .line_rd_data_ready(PI_line_rd_data_ready),
    .axi_rdata(PI_axi_rdata),
    .line_wr_rsp_ready(PI_line_wr_rsp_ready),
    .line_rd_req_addr(PI_line_rd_req_addr),
    .line_wr_data_last(PI_line_wr_data_last),
    .line_wr_data(PI_line_wr_data),
    .axi_arready(PI_axi_arready),
    .axi_rid(PI_axi_rid),
    .axi_rlast(PI_axi_rlast),
    .line_rd_req_valid(PI_line_rd_req_valid),
    .line_wr_req_addr(PI_line_wr_req_addr)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$3286  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3298  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3322  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3382  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3388  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3406  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3412  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3290  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3296  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3308  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3314  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3320  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3326  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3332  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3338  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3344  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3350  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3380  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3386  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3392  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3398  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3404  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3410  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3416  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3422  = 1'b0;
    UUT._witness_.anyinit_past_1018 = 1'b0;
    UUT._witness_.anyinit_past_925 = 1'b0;
    UUT._witness_.anyinit_past_933 = 1'b0;
    UUT._witness_.anyinit_past_939 = 71'b00000000000000000000000000000000000000000000000000000000000000000000000;
    UUT._witness_.anyinit_past_944 = 1'b0;
    UUT._witness_.anyinit_past_950 = 6'b000000;
    UUT._witness_.anyinit_past_955 = 1'b0;
    UUT._witness_.anyinit_past_961 = 36'b000000000000000000000000000000000000;
    UUT.dut.rd_ar_count_q = 3'b101;
    UUT.dut.\rd_ar_fifo_q[0]  = 2'b00;
    UUT.dut.\rd_ar_fifo_q[1]  = 2'b10;
    UUT.dut.\rd_ar_fifo_q[2]  = 2'b10;
    UUT.dut.\rd_ar_fifo_q[3]  = 2'b11;
    UUT.dut.rd_ar_head_q = 2'b01;
    UUT.dut.rd_ar_tail_q = 2'b11;
    UUT.dut.\rd_beat_q[0]  = 3'b001;
    UUT.dut.\rd_beat_q[1]  = 3'b100;
    UUT.dut.\rd_beat_q[2]  = 3'b000;
    UUT.dut.\rd_beat_q[3]  = 3'b010;
    UUT.dut.\rd_drain_q[0]  = 1'b0;
    UUT.dut.\rd_drain_q[1]  = 1'b1;
    UUT.dut.\rd_drain_q[2]  = 1'b0;
    UUT.dut.\rd_drain_q[3]  = 1'b0;
    UUT.dut.\rd_id_q[0]  = 4'b0001;
    UUT.dut.\rd_id_q[1]  = 4'b0100;
    UUT.dut.\rd_id_q[2]  = 4'b0010;
    UUT.dut.\rd_id_q[3]  = 4'b0001;
    UUT.dut.\rd_issued_q[0]  = 1'b0;
    UUT.dut.\rd_issued_q[1]  = 1'b1;
    UUT.dut.\rd_issued_q[2]  = 1'b1;
    UUT.dut.\rd_issued_q[3]  = 1'b1;
    UUT.dut.\rd_valid_q[0]  = 1'b1;
    UUT.dut.\rd_valid_q[1]  = 1'b1;
    UUT.dut.\rd_valid_q[2]  = 1'b1;
    UUT.dut.\rd_valid_q[3]  = 1'b1;
    UUT.dut.\wr_addr_q[0]  = 32'b01000000000000000000010000000000;
    UUT.dut.\wr_addr_q[1]  = 32'b00000000100000000000000000000000;
    UUT.dut.\wr_addr_q[2]  = 32'b00000000000000000000100000000000;
    UUT.dut.\wr_addr_q[3]  = 32'b00000000000000000000000000001000;
    UUT.dut.wr_aw_count_q = 3'b111;
    UUT.dut.\wr_aw_fifo_q[0]  = 2'b10;
    UUT.dut.\wr_aw_fifo_q[1]  = 2'b00;
    UUT.dut.\wr_aw_fifo_q[2]  = 2'b11;
    UUT.dut.\wr_aw_fifo_q[3]  = 2'b01;
    UUT.dut.wr_aw_head_q = 2'b10;
    UUT.dut.\wr_aw_sent_q[0]  = 1'b0;
    UUT.dut.\wr_aw_sent_q[1]  = 1'b1;
    UUT.dut.\wr_aw_sent_q[2]  = 1'b1;
    UUT.dut.\wr_aw_sent_q[3]  = 1'b1;
    UUT.dut.wr_aw_tail_q = 2'b11;
    UUT.dut.\wr_data_count_q[0]  = 4'b0000;
    UUT.dut.\wr_data_count_q[1]  = 4'b0010;
    UUT.dut.\wr_data_count_q[2]  = 4'b1000;
    UUT.dut.\wr_data_count_q[3]  = 4'b0110;
    UUT.dut.\wr_id_q[0]  = 4'b0010;
    UUT.dut.\wr_id_q[1]  = 4'b1000;
    UUT.dut.\wr_id_q[2]  = 4'b0011;
    UUT.dut.\wr_id_q[3]  = 4'b1000;
    UUT.dut.\wr_valid_q[0]  = 1'b1;
    UUT.dut.\wr_valid_q[1]  = 1'b1;
    UUT.dut.\wr_valid_q[2]  = 1'b0;
    UUT.dut.\wr_valid_q[3]  = 1'b1;
    UUT.dut.wr_w_count_q = 3'b010;
    UUT.dut.\wr_w_done_q[0]  = 1'b1;
    UUT.dut.\wr_w_done_q[1]  = 1'b0;
    UUT.dut.\wr_w_done_q[2]  = 1'b0;
    UUT.dut.\wr_w_done_q[3]  = 1'b1;
    UUT.dut.\wr_w_fifo_q[0]  = 2'b11;
    UUT.dut.\wr_w_fifo_q[1]  = 2'b10;
    UUT.dut.\wr_w_fifo_q[2]  = 2'b00;
    UUT.dut.\wr_w_fifo_q[3]  = 2'b10;
    UUT.dut.wr_w_head_q = 2'b11;
    UUT.dut.\wr_w_sent_count_q[0]  = 4'b0100;
    UUT.dut.\wr_w_sent_count_q[1]  = 4'b0010;
    UUT.dut.\wr_w_sent_count_q[2]  = 4'b0110;
    UUT.dut.\wr_w_sent_count_q[3]  = 4'b1010;
    UUT.dut.wr_w_tail_q = 2'b01;
    UUT.init_count = 2'b10;
    UUT.past_valid = 1'b0;

    // state 0
    PI_axi_rresp = 2'b00;
    PI_reset_later = 1'b0;
    PI_line_wr_data_beat = 3'b000;
    PI_axi_bvalid = 1'b0;
    PI_line_wr_data_valid = 1'b0;
    PI_line_wr_req_valid = 1'b0;
    PI_line_wr_data_id = 4'b1000;
    PI_axi_awready = 1'b0;
    PI_axi_rvalid = 1'b0;
    PI_axi_bid = 4'b0100;
    PI_line_rd_req_id = 4'b0100;
    PI_axi_wready = 1'b1;
    PI_axi_bresp = 2'b00;
    PI_line_wr_req_id = 4'b0010;
    PI_line_rd_data_ready = 1'b0;
    PI_axi_rdata = 64'b0000000000000000000000000000000000000000000000000000000000000000;
    PI_line_wr_rsp_ready = 1'b0;
    PI_line_rd_req_addr = 32'b00000000000000000000000000000000;
    PI_line_wr_data_last = 1'b0;
    PI_line_wr_data = 64'b0000000000000000000000000000000000000000000000000000000000000000;
    PI_axi_arready = 1'b0;
    PI_axi_rid = 4'b0000;
    PI_axi_rlast = 1'b1;
    PI_line_rd_req_valid = 1'b0;
    PI_line_wr_req_addr = 32'b00000000000000000000000000000000;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_axi_rresp <= 2'b00;
      PI_reset_later <= 1'b0;
      PI_line_wr_data_beat <= 3'b000;
      PI_axi_bvalid <= 1'b0;
      PI_line_wr_data_valid <= 1'b1;
      PI_line_wr_req_valid <= 1'b1;
      PI_line_wr_data_id <= 4'b0010;
      PI_axi_awready <= 1'b1;
      PI_axi_rvalid <= 1'b0;
      PI_axi_bid <= 4'b0000;
      PI_line_rd_req_id <= 4'b0001;
      PI_axi_wready <= 1'b1;
      PI_axi_bresp <= 2'b00;
      PI_line_wr_req_id <= 4'b0000;
      PI_line_rd_data_ready <= 1'b0;
      PI_axi_rdata <= 64'b0000000000000000000000000010000000000000000000000000000000000000;
      PI_line_wr_rsp_ready <= 1'b0;
      PI_line_rd_req_addr <= 32'b00000000000000000000000000000000;
      PI_line_wr_data_last <= 1'b0;
      PI_line_wr_data <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_axi_arready <= 1'b1;
      PI_axi_rid <= 4'b0010;
      PI_axi_rlast <= 1'b0;
      PI_line_rd_req_valid <= 1'b0;
      PI_line_wr_req_addr <= 32'b00010000000000000000000000000000;
    end

    // state 2
    if (cycle == 1) begin
      PI_axi_rresp <= 2'b00;
      PI_reset_later <= 1'b0;
      PI_line_wr_data_beat <= 3'b000;
      PI_axi_bvalid <= 1'b0;
      PI_line_wr_data_valid <= 1'b1;
      PI_line_wr_req_valid <= 1'b0;
      PI_line_wr_data_id <= 4'b1000;
      PI_axi_awready <= 1'b0;
      PI_axi_rvalid <= 1'b0;
      PI_axi_bid <= 4'b0000;
      PI_line_rd_req_id <= 4'b1010;
      PI_axi_wready <= 1'b0;
      PI_axi_bresp <= 2'b10;
      PI_line_wr_req_id <= 4'b1000;
      PI_line_rd_data_ready <= 1'b0;
      PI_axi_rdata <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_line_wr_rsp_ready <= 1'b1;
      PI_line_rd_req_addr <= 32'b00000000000000000000000000000000;
      PI_line_wr_data_last <= 1'b0;
      PI_line_wr_data <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_axi_arready <= 1'b1;
      PI_axi_rid <= 4'b0100;
      PI_axi_rlast <= 1'b0;
      PI_line_rd_req_valid <= 1'b1;
      PI_line_wr_req_addr <= 32'b00000000000000000000000000000000;
    end

    // state 3
    if (cycle == 2) begin
      PI_axi_rresp <= 2'b00;
      PI_reset_later <= 1'b0;
      PI_line_wr_data_beat <= 3'b000;
      PI_axi_bvalid <= 1'b1;
      PI_line_wr_data_valid <= 1'b0;
      PI_line_wr_req_valid <= 1'b0;
      PI_line_wr_data_id <= 4'b0001;
      PI_axi_awready <= 1'b0;
      PI_axi_rvalid <= 1'b0;
      PI_axi_bid <= 4'b0010;
      PI_line_rd_req_id <= 4'b0001;
      PI_axi_wready <= 1'b0;
      PI_axi_bresp <= 2'b10;
      PI_line_wr_req_id <= 4'b1000;
      PI_line_rd_data_ready <= 1'b0;
      PI_axi_rdata <= 64'b1000000000000000000000000000000000000000000000000000000000000000;
      PI_line_wr_rsp_ready <= 1'b1;
      PI_line_rd_req_addr <= 32'b00000000000000000000000000000000;
      PI_line_wr_data_last <= 1'b0;
      PI_line_wr_data <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_axi_arready <= 1'b0;
      PI_axi_rid <= 4'b1100;
      PI_axi_rlast <= 1'b0;
      PI_line_rd_req_valid <= 1'b0;
      PI_line_wr_req_addr <= 32'b00000000000000000000000000000000;
    end

    // state 4
    if (cycle == 3) begin
      PI_axi_rresp <= 2'b01;
      PI_reset_later <= 1'b0;
      PI_line_wr_data_beat <= 3'b000;
      PI_axi_bvalid <= 1'b1;
      PI_line_wr_data_valid <= 1'b0;
      PI_line_wr_req_valid <= 1'b0;
      PI_line_wr_data_id <= 4'b0000;
      PI_axi_awready <= 1'b0;
      PI_axi_rvalid <= 1'b1;
      PI_axi_bid <= 4'b0000;
      PI_line_rd_req_id <= 4'b0100;
      PI_axi_wready <= 1'b0;
      PI_axi_bresp <= 2'b01;
      PI_line_wr_req_id <= 4'b1000;
      PI_line_rd_data_ready <= 1'b1;
      PI_axi_rdata <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_line_wr_rsp_ready <= 1'b1;
      PI_line_rd_req_addr <= 32'b00000000000000000000000000000000;
      PI_line_wr_data_last <= 1'b0;
      PI_line_wr_data <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_axi_arready <= 1'b1;
      PI_axi_rid <= 4'b0010;
      PI_axi_rlast <= 1'b1;
      PI_line_rd_req_valid <= 1'b0;
      PI_line_wr_req_addr <= 32'b00000000000000000000000000000000;
    end

    // state 5
    if (cycle == 4) begin
      PI_axi_rresp <= 2'b00;
      PI_reset_later <= 1'b0;
      PI_line_wr_data_beat <= 3'b000;
      PI_axi_bvalid <= 1'b0;
      PI_line_wr_data_valid <= 1'b1;
      PI_line_wr_req_valid <= 1'b0;
      PI_line_wr_data_id <= 4'b1000;
      PI_axi_awready <= 1'b0;
      PI_axi_rvalid <= 1'b1;
      PI_axi_bid <= 4'b0000;
      PI_line_rd_req_id <= 4'b0100;
      PI_axi_wready <= 1'b0;
      PI_axi_bresp <= 2'b00;
      PI_line_wr_req_id <= 4'b1000;
      PI_line_rd_data_ready <= 1'b0;
      PI_axi_rdata <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_line_wr_rsp_ready <= 1'b0;
      PI_line_rd_req_addr <= 32'b00000000000000000000000000000000;
      PI_line_wr_data_last <= 1'b0;
      PI_line_wr_data <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_axi_arready <= 1'b0;
      PI_axi_rid <= 4'b0100;
      PI_axi_rlast <= 1'b1;
      PI_line_rd_req_valid <= 1'b0;
      PI_line_wr_req_addr <= 32'b00000000000000000000000000000000;
    end

    // state 6
    if (cycle == 5) begin
      PI_axi_rresp <= 2'b00;
      PI_reset_later <= 1'b0;
      PI_line_wr_data_beat <= 3'b000;
      PI_axi_bvalid <= 1'b0;
      PI_line_wr_data_valid <= 1'b0;
      PI_line_wr_req_valid <= 1'b1;
      PI_line_wr_data_id <= 4'b1110;
      PI_axi_awready <= 1'b0;
      PI_axi_rvalid <= 1'b1;
      PI_axi_bid <= 4'b1000;
      PI_line_rd_req_id <= 4'b0001;
      PI_axi_wready <= 1'b1;
      PI_axi_bresp <= 2'b10;
      PI_line_wr_req_id <= 4'b0001;
      PI_line_rd_data_ready <= 1'b1;
      PI_axi_rdata <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_line_wr_rsp_ready <= 1'b1;
      PI_line_rd_req_addr <= 32'b00000000000000000000000000000000;
      PI_line_wr_data_last <= 1'b0;
      PI_line_wr_data <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_axi_arready <= 1'b1;
      PI_axi_rid <= 4'b0001;
      PI_axi_rlast <= 1'b1;
      PI_line_rd_req_valid <= 1'b0;
      PI_line_wr_req_addr <= 32'b00010000000000000000000000100000;
    end

    // state 7
    if (cycle == 6) begin
      PI_axi_rresp <= 2'b00;
      PI_reset_later <= 1'b0;
      PI_line_wr_data_beat <= 3'b000;
      PI_axi_bvalid <= 1'b1;
      PI_line_wr_data_valid <= 1'b0;
      PI_line_wr_req_valid <= 1'b0;
      PI_line_wr_data_id <= 4'b1000;
      PI_axi_awready <= 1'b0;
      PI_axi_rvalid <= 1'b0;
      PI_axi_bid <= 4'b0001;
      PI_line_rd_req_id <= 4'b0001;
      PI_axi_wready <= 1'b1;
      PI_axi_bresp <= 2'b00;
      PI_line_wr_req_id <= 4'b1000;
      PI_line_rd_data_ready <= 1'b0;
      PI_axi_rdata <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_line_wr_rsp_ready <= 1'b0;
      PI_line_rd_req_addr <= 32'b00000000000000000000000000000000;
      PI_line_wr_data_last <= 1'b0;
      PI_line_wr_data <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_axi_arready <= 1'b1;
      PI_axi_rid <= 4'b1110;
      PI_axi_rlast <= 1'b0;
      PI_line_rd_req_valid <= 1'b0;
      PI_line_wr_req_addr <= 32'b00000000100000000000000000000000;
    end

    // state 8
    if (cycle == 7) begin
      PI_axi_rresp <= 2'b00;
      PI_reset_later <= 1'b1;
      PI_line_wr_data_beat <= 3'b000;
      PI_axi_bvalid <= 1'b0;
      PI_line_wr_data_valid <= 1'b0;
      PI_line_wr_req_valid <= 1'b0;
      PI_line_wr_data_id <= 4'b1000;
      PI_axi_awready <= 1'b0;
      PI_axi_rvalid <= 1'b0;
      PI_axi_bid <= 4'b0010;
      PI_line_rd_req_id <= 4'b0001;
      PI_axi_wready <= 1'b0;
      PI_axi_bresp <= 2'b00;
      PI_line_wr_req_id <= 4'b1000;
      PI_line_rd_data_ready <= 1'b0;
      PI_axi_rdata <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_line_wr_rsp_ready <= 1'b1;
      PI_line_rd_req_addr <= 32'b00000000000000000000000000000000;
      PI_line_wr_data_last <= 1'b0;
      PI_line_wr_data <= 64'b0000000000000000000000000000000000000000000000000000000000000000;
      PI_axi_arready <= 1'b1;
      PI_axi_rid <= 4'b0000;
      PI_axi_rlast <= 1'b0;
      PI_line_rd_req_valid <= 1'b0;
      PI_line_wr_req_addr <= 32'b00000000000000000000000000000000;
    end

    genclock <= cycle < 8;
    cycle <= cycle + 1;
  end
endmodule
